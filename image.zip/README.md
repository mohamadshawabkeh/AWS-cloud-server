# aws-server-GUI
![Alt text](image.png)

http://aws-server1-env.eba-whqi3f32.us-east-1.elasticbeanstalk.com/